﻿using System;
public class overload
{
    public void display()

    {
        Console.WriteLine("HI");
    }
    public void display(string a, string b)

    {
        Console.WriteLine("my name is " + a + "--" + b + "--");
    }
}