﻿using System;
public class Sample {
    public static int count = 0;
    public void addnum() {
        count++;
    }
    public void display() { 
    Console.WriteLine(count);
        }
}