﻿using System;

class Person
{
    public string name;
    public int age;
}

class Student : Person
{
    public int rollno;
}
